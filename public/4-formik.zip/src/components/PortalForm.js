import React from 'react';

function PortalForm() {
  return <div>PortalForm</div>;
}

export default PortalForm;
